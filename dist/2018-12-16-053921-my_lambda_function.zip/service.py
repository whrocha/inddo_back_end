# -*- coding: utf-8 -*-


def handler(event, context):
    # Your code goes here!
    e = 2#event.get('e')
    pi = 2#event.get('pi')
    return {
        "statusCode": 200,
        "headers": { "Content-Type": "application/json"},
        "body": e + pi
    }