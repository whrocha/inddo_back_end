# -*- coding: utf-8 -*-
#import boto3
#import random
#import json

def handler(event, context):
    # Your code goes here!
    #e = 2#event.get('e')
    #pi = 2#event.get('pi')
    #return {
    #    "statusCode": 200,
    #    "headers": { "Content-Type": "application/json"},
    #    "body": e + pi
    #}
    #if __name__ == "__main__":
    #teste = 'oi'

    #bucket = 'hackadasa'
    #photo = 'guia_1.png'

    #client = boto3.client('rekognition')
	
	#try:
	#	response = client.detect_text(Image={'S3Object':{'Bucket':bucket,'Name':photo}})
	#except Exception as e:
	#	teste = str(e)

	#try:
	#	response = client.detect_text(Image={'S3Object':{'Bucket':bucket,'Name':photo}})
	#except Exception as e:
	#	teste = str(e)

	#try:
	#	pass
	#except Exception as e:
	#	raise e
  

                        
    #textDetections = response['TextDetections']
    #print( response)
    #print( 'Matching faces')
    
    #result = {"data":[]}
    
    #json_data["key"] = "value"

    #for text in textDetections:
    #    #print( 'Detected text:' + text['DetectedText'])
    #    #print( 'Confidence: ' + "{:.2f}".format(text['Confidence']) + "%")
    #    #print( 'Id: {}'.format(text['Id']))
    #    #if 'ParentId' in text:
    #    #    print( 'Parent Id: {}'.format(text['ParentId']))
    #    #print('Type:' + text['Type'])
    #    #print("")
    #    if text['Id'] >= 8 and text['Id'] <= 11:
    #        #print( 'Detected text:' + text['DetectedText'][3:] + ' Value: ' + str(random.randint(0,1)))
    #        result["data"].append({'exam':text['DetectedText'][3:],
    #      		                   'chk':random.randint(0,1)})
    #        teste = text['DetectedText'][3:]

    #json_data = result#json.dumps(result, indent=4)
    

    teste = {'data': [{'exam': 'Glicose', 'chk': 1}, {'exam': 'Creatinina', 'chk': 0}, {'exam': 'Colesterol Hdl', 'chk': 0}, {'exam': 'Ureia', 'chk': 0}]}

    return {
        "statusCode": 200,
        "headers": { "Content-Type": "application/json"},
        "body": teste
    }